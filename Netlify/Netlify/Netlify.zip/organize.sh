#!/bin/bash
# Script لتنظيم ملفات Vortex

echo "🔧 تنظيم ملفات Vortex..."
echo "=========================="

# نقل netlify.toml إلى الجذر إذا كان في config
if [ -f "config/netlify.toml" ]; then
    mv config/netlify.toml .
    echo "✓ netlify.toml moved to root"
fi

# نقل package.json إلى الجذر إذا كان في config
if [ -f "config/package.json" ]; then
    mv config/package.json .
    echo "✓ package.json moved to root"
fi

# تأكد من وجود مجلدات أساسية
mkdir -p public/{css,js,assets} scripts config docs

echo "✅ التنظيم اكتمل!"
echo "📁 الهيكل الحالي:"
tree -I 'node_modules|__pycache__' --dirsfirst -L 2
