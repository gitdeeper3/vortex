from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="vortex-by-gitdeeper",
    version="0.2.0",
    author="gitdeeper",
    description="Computational fluid dynamics simulation package for vortex analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.com/gitdeeper3/vortex",
    project_urls={
        "Bug Tracker": "https://gitlab.com/gitdeeper3/vortex/issues",
        "Source Code": "https://gitlab.com/gitdeeper3/vortex",
    },
    packages=[
        'src',
        'src.algorithms', 
        'src.core',
        'src.io',
        'src.parameters',
        'src.utils',
        'src.visualization'
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Physics",
        "Topic :: Scientific/Engineering :: Simulation",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
    ],
    keywords=[
        "vortex", 
        "simulation", 
        "cfd", 
        "fluid-dynamics", 
        "physics",
        "scientific",
        "engineering"
    ],
)
