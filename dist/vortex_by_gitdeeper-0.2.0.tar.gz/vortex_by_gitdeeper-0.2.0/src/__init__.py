"""
Vortex Simulation Package
Computational fluid dynamics and vortex modeling
"""

__version__ = "0.1.0"
__author__ = "gitdeeper3"

# استيرادات اختيارية - يمكن حذفها إذا كانت تسبب مشاكل
# from src.core.vortex_engine import VortexEngine
# from src.algorithms.time_stepping import TimeStepper

# __all__ = ['VortexEngine', 'TimeStepper']
